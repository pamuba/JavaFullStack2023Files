import './App.css';
import CakeContainer from './components/CakeContainer';
import { Provider } from 'react-redux'
import store from './redux/store'
import HooksCakeContainer from './components/HooksCakeContainer';
import IceCreamContainer from './components/IceCreamContainer';
import NewCakeContainer from './components/NewCakeContainer';
import UserContainer from './components/UserContainer';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Provider store={store}>
        <CakeContainer/>
          {/* <UserContainer/> */}
          {/* <HooksCakeContainer />
          <CakeContainer/>
          <IceCreamContainer/>
          <NewCakeContainer/> */}
        </Provider>
      </header>
    </div>
  );
}

export default App;
